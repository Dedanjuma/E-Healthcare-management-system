var dp_call,dp_cal2;      
window.onload = function () {
	//bas_cal = new Epoch('epoch_basic','flat',document.getElementById('basic_container'));
 
	dp_cal1  = new Epoch('epoch_popup','popup',document.getElementById('popup_container1'));
	//ms_cal  = new Epoch('epoch_multi','flat',document.getElementById('multi_container'),true);
};





