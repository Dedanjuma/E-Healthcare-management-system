package com.G37.labadmin;

public class MultipartFormDataRequest {

}
