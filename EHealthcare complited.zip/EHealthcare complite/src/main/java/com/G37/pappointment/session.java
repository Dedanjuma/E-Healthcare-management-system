
package com.G37.pappointment;

/**
 *
 * @author Dedan
 */
class session {

}
